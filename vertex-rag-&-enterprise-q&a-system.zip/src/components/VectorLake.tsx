import React, { useState } from 'react';
import {
  Database,
  FileText,
  UploadCloud,
  Plus,
  Trash2,
  Layers,
  Sparkles,
  Search,
  CheckCircle2,
  Radio,
  RefreshCw,
} from 'lucide-react';
import { DocumentItem, DocumentChunk } from '../types';

interface VectorLakeProps {
  documents: DocumentItem[];
  onIngestDocument: (doc: { title: string; category: DocumentItem['category']; source: string; content: string }) => Promise<void>;
  onDeleteDocument: (id: string) => Promise<void>;
  loading: boolean;
}

export const VectorLake: React.FC<VectorLakeProps> = ({
  documents,
  onIngestDocument,
  onDeleteDocument,
  loading,
}) => {
  const [selectedDocId, setSelectedDocId] = useState<string>(documents[0]?.id || '');
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isSimulatingStream, setIsSimulatingStream] = useState(false);
  const [streamLog, setStreamLog] = useState<string[]>([]);

  // New doc form state
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<DocumentItem['category']>('Custom Ingestion');
  const [newSource, setNewSource] = useState('');
  const [newContent, setNewContent] = useState('');

  const activeDoc = documents.find((d) => d.id === selectedDocId) || documents[0];

  const handleCreateDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    await onIngestDocument({
      title: newTitle.trim(),
      category: newCategory,
      source: newSource.trim() || 'Manual Input',
      content: newContent.trim(),
    });

    setNewTitle('');
    setNewSource('');
    setNewContent('');
    setShowUploadModal(false);
  };

  // Live real-time ingestion simulation
  const handleSimulateRealtimeStream = async () => {
    setIsSimulatingStream(true);
    setStreamLog([]);

    const addLog = (msg: string) => {
      setStreamLog((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${msg}`]);
    };

    addLog('Eventarc event received: gcs.object.finalize on gs://corp-rag-documents/sec-filings/alphabet-q1-2024-8k.txt');
    await new Promise((r) => setTimeout(r, 600));

    addLog('Cloud Run Ingestion Worker invoked: Container cold-start 18ms (min-instances=1)');
    await new Promise((r) => setTimeout(r, 600));

    addLog('Executing Sentence-Aware Token Chunking: 3 chunks generated (Target: 420 tokens, 60 token overlap)');
    await new Promise((r) => setTimeout(r, 700));

    addLog('Calling Vertex AI text-embedding model: 768-dimensional dense vectors generated');
    await new Promise((r) => setTimeout(r, 800));

    addLog('Streaming index update to Vertex Vector Search (ScaNN): zero-downtime mutation complete');
    await new Promise((r) => setTimeout(r, 500));

    const simulatedDoc = {
      title: 'Alphabet Inc. Form 8-K (Q1 FY24 Material Update)',
      category: '10-K Financials' as const,
      source: 'SEC EDGAR Live Ingestion Pipeline',
      content: `ITEM 2.02 RESULTS OF OPERATIONS AND FINANCIAL CONDITION:
For the first quarter ended March 31, 2024, Alphabet reported consolidated revenues of $80.5 billion, an increase of 15% year-over-year. Google Cloud revenues accelerated to $9.57 billion, up 28% year-over-year, delivering operating income of $900 million. Operating margin reached 32% for the consolidated enterprise.

ITEM 7.01 REGULATION FD DISCLOSURE - CAPITAL RETURN & DIVIDEND INAUGURATION:
The Board of Directors declared an inaugural cash dividend of $0.20 per share, payable on June 17, 2024, to stockholders of record as of June 10, 2024. In addition, the Board authorized an additional $70.0 billion in Class A and Class C share repurchases, reflecting continued disciplined cash generation alongside aggressive technical AI infrastructure investments.`,
    };

    await onIngestDocument(simulatedDoc);
    addLog('Document successfully added to active vector store. Ready for real-time Q&A.');
    setIsSimulatingStream(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full flex items-center">
                <Database className="w-3 h-3 mr-1 text-blue-400" /> Vector Lake & Ingestion Pipeline
              </span>
              <span className="text-xs text-slate-400">Cloud Storage + Vertex Vector Search</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight mt-2 text-white">
              Enterprise Document & Vector Index
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Inspect chunked document representations, manage enterprise corpora, and test real-time streaming ingestion from Cloud Storage event triggers.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleSimulateRealtimeStream}
              disabled={isSimulatingStream}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold transition-all shadow-md shadow-emerald-600/30 flex items-center space-x-1.5 disabled:opacity-50"
            >
              {isSimulatingStream ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Streaming Ingestion...</span>
                </>
              ) : (
                <>
                  <Radio className="w-3.5 h-3.5 animate-pulse" />
                  <span>Simulate Real-time Stream</span>
                </>
              )}
            </button>

            <button
              onClick={() => setShowUploadModal(true)}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold transition-all shadow-md shadow-blue-600/30 flex items-center space-x-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Ingest Document</span>
            </button>
          </div>
        </div>

        {/* Real-time streaming log terminal if active */}
        {(isSimulatingStream || streamLog.length > 0) && (
          <div className="mt-4 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono space-y-1 max-h-36 overflow-y-auto">
            <div className="text-[10px] text-emerald-400 font-bold uppercase tracking-wider flex items-center mb-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5 animate-ping"></span>
              Eventarc / Cloud Run Streaming Ingestion Worker Log:
            </div>
            {streamLog.map((log, i) => (
              <div key={i} className="text-slate-300">
                {log}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Main Grid: Document List & Chunk Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 4 Cols: Document Catalog */}
        <div className="lg:col-span-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm flex items-center">
              <FileText className="w-4 h-4 mr-1.5 text-blue-600" />
              Indexed Documents ({documents.length})
            </h3>
            <span className="text-xs text-slate-500">ScaNN Vector Lake</span>
          </div>

          <div className="space-y-2">
            {documents.map((doc) => {
              const isSelected = doc.id === activeDoc?.id;
              return (
                <div
                  key={doc.id}
                  onClick={() => setSelectedDocId(doc.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-blue-50/80 border-blue-500 shadow-xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        doc.category === '10-K Financials'
                          ? 'bg-amber-100 text-amber-800'
                          : doc.category === 'HR & Policy'
                          ? 'bg-purple-100 text-purple-800'
                          : doc.category === 'GCP Docs'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-emerald-100 text-emerald-800'
                      }`}
                    >
                      {doc.category}
                    </span>

                    {documents.length > 1 && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Remove "${doc.title}" from vector store?`)) {
                            onDeleteDocument(doc.id);
                          }
                        }}
                        className="text-slate-400 hover:text-red-600 transition-colors p-1"
                        title="Delete document"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <h4 className="font-semibold text-slate-900 text-sm mt-2 line-clamp-1">
                    {doc.title}
                  </h4>
                  <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{doc.source}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono mt-3 pt-2 border-t border-slate-100">
                    <span>{doc.chunks?.length || doc.chunkCount} chunks</span>
                    <span>~{doc.totalTokens} tokens</span>
                    <span>{doc.date}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 8 Cols: Chunk & Vector Inspector */}
        <div className="lg:col-span-8 space-y-4">
          {activeDoc ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-5">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-4 border-b border-slate-100 gap-2">
                <div>
                  <span className="text-[10px] font-mono text-blue-600 font-semibold uppercase">
                    Document ID: {activeDoc.id}
                  </span>
                  <h3 className="font-bold text-slate-900 text-base mt-0.5">
                    {activeDoc.title}
                  </h3>
                  <span className="text-xs text-slate-500">{activeDoc.source}</span>
                </div>

                <div className="flex items-center space-x-2 text-xs font-mono">
                  <span className="px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700">
                    {activeDoc.chunks?.length || 0} Chunks
                  </span>
                  <span className="px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700">
                    ~{activeDoc.totalTokens} Tokens
                  </span>
                </div>
              </div>

              {/* Chunks List */}
              <div className="space-y-3">
                <h4 className="font-semibold text-slate-900 text-xs uppercase tracking-wider flex items-center text-slate-500">
                  <Layers className="w-3.5 h-3.5 mr-1 text-blue-600" />
                  Indexed Passage Chunks (Paragraph-Aware Splitter, 420-Token Target)
                </h4>

                {activeDoc.chunks && activeDoc.chunks.length > 0 ? (
                  <div className="space-y-3">
                    {activeDoc.chunks.map((chk, i) => (
                      <div
                        key={chk.id || i}
                        className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 hover:border-blue-300 transition-colors space-y-2"
                      >
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-mono font-bold text-blue-700">
                            Chunk #{chk.chunkIndex} ({chk.id})
                          </span>
                          <span className="text-slate-400 font-mono text-[11px]">
                            ~{chk.tokenCount} tokens
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 font-mono leading-relaxed whitespace-pre-wrap">
                          {chk.text}
                        </p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-4 text-xs text-slate-500 font-mono whitespace-pre-wrap bg-slate-50 rounded-xl">
                    {activeDoc.content}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center text-slate-400 text-sm">
              Select a document to inspect its chunk representations.
            </div>
          )}
        </div>
      </div>

      {/* Upload / Ingest Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h4 className="font-bold text-slate-900 text-base flex items-center">
                <UploadCloud className="w-5 h-5 mr-2 text-blue-600" />
                Ingest New Document to Vector Lake
              </h4>
              <button
                onClick={() => setShowUploadModal(false)}
                className="text-slate-400 hover:text-slate-700 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="py-4 space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Title
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Enterprise Security & Disaster Recovery SLA"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Corpus Category
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  >
                    <option value="10-K Financials">10-K Financials</option>
                    <option value="HR & Policy">HR & Policy</option>
                    <option value="GCP Docs">GCP Docs</option>
                    <option value="Custom Ingestion">Custom Ingestion</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Source Citation
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Corporate Compliance Handbook v5"
                    value={newSource}
                    onChange={(e) => setNewSource(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Document Content (Raw Text / Markdown)
                </label>
                <textarea
                  required
                  rows={8}
                  placeholder="Paste multi-paragraph text here. Paragraph-aware token chunking and vector embeddings will be computed automatically..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full p-3 border border-slate-300 rounded-lg text-xs font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-semibold shadow-md shadow-blue-600/30"
                >
                  Chunk & Index Document
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
