import React, { useState } from 'react';
import {
  FileCode,
  CheckCircle2,
  Server,
  Cloud,
  Layers,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  Cpu,
  Database,
  Lock,
  Zap,
} from 'lucide-react';
import { ADR } from '../types';
import { ARCHITECTURE_DECISION_RECORDS } from '../data/adrsAndCost';

export const ArchitectureView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'topology' | 'adrs' | 'iac'>('topology');
  const [expandedAdr, setExpandedAdr] = useState<string>('ADR-001');
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedNode, setSelectedNode] = useState<string>('cloudrun');

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const TERRAFORM_IAC = `# Google Cloud Platform - Enterprise Vertex RAG Production Module
# Provider configuration
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.20.0"
    }
  }
}

variable "project_id" {
  description = "GCP Project ID"
  type        = string
  default     = "enterprise-genai-prod"
}

variable "region" {
  description = "Primary GCP Region"
  type        = string
  default     = "us-central1"
}

# 1. Cloud Storage Document Lake
resource "google_storage_bucket" "rag_documents" {
  name          = "\${var.project_id}-rag-documents"
  location      = var.region
  force_destroy = false
  uniform_bucket_level_access = true

  versioning {
    enabled = true
  }

  encryption {
    default_kms_key_name = google_kms_crypto_key.rag_key.id
  }
}

# 2. Vertex AI Vector Search (ScaNN Index)
resource "google_vertex_ai_index" "enterprise_vector_index" {
  display_name = "corp-vector-index-scann"
  description  = "ScaNN Asymmetric Hashing Index for Enterprise 10-K & HR Embeddings"
  region       = var.region

  metadata {
    contents_delta_uri = "gs://\${google_storage_bucket.rag_documents.name}/embeddings/"
    config {
      dimensions                  = 768
      approximate_neighbors_count = 150
      distance_measure_type       = "COSINE_DISTANCE"
      algorithm_config {
        tree_ah_config {
          leaf_node_embedding_count    = 1000
          leaf_nodes_to_search_percent = 10
        }
      }
    }
  }
}

# 3. Vertex AI Vector Search Index Endpoint
resource "google_vertex_ai_index_endpoint" "index_endpoint" {
  display_name = "corp-vector-endpoint"
  region       = var.region
  public_endpoint_enabled = false
  network     = "projects/\${var.project_id}/global/networks/vpc-enterprise"
}

# 4. Cloud Run Gen2 Orchestration API Service
resource "google_cloud_run_v2_service" "rag_api" {
  name     = "vertex-rag-api"
  location = var.region
  ingress  = "INGRESS_TRAFFIC_INTERNAL_LOAD_BALANCER"

  template {
    scaling {
      min_instance_count = 1  # Eliminates cold starts (<30ms gateway SLA)
      max_instance_count = 100
    }

    containers {
      image = "us-central1-docker.pkg.dev/\${var.project_id}/rag-repo/api:latest"
      resources {
        limits = {
          cpu    = "2000m"
          memory = "4Gi"
        }
      }
      env {
        name  = "VERTEX_INDEX_ENDPOINT"
        value = google_vertex_ai_index_endpoint.index_endpoint.id
      }
      env {
        name  = "GEMINI_MODEL"
        value = "gemini-2.5-pro"
      }
    }
  }
}`;

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full flex items-center">
                <FileCode className="w-3.5 h-3.5 mr-1 text-blue-400" /> Architecture Decision Records & Blueprint
              </span>
              <span className="text-xs text-slate-400">Google Cloud Architecture Center Specs</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight mt-2 text-white">
              GCP Reference Architecture & ADRs
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Formal engineering documentation explaining why Serverless Cloud Run and Vertex Vector Search were selected over GKE, backed by Michael Nygard ADR standards and production Terraform IaC.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs font-mono text-slate-300 flex items-center">
              <Lock className="w-3.5 h-3.5 mr-1 text-emerald-400" /> VPC-SC & CMEK Encrypted
            </span>
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex space-x-2 mt-6 pt-4 border-t border-slate-800">
          <button
            onClick={() => setActiveTab('topology')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'topology'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Interactive GCP Topology Diagram
          </button>
          <button
            onClick={() => setActiveTab('adrs')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'adrs'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Architecture Decision Records (ADRs)
          </button>
          <button
            onClick={() => setActiveTab('iac')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeTab === 'iac'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-400 hover:text-white bg-slate-800/60'
            }`}
          >
            Terraform IaC & Docker Spec
          </button>
        </div>
      </div>

      {/* View 1: Topology Diagram */}
      {activeTab === 'topology' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  Production Cloud Architecture Topology
                </h3>
                <p className="text-xs text-slate-500">
                  Click on any architecture node to inspect its operational role, SLA parameters, and cost tier.
                </p>
              </div>
              <span className="text-xs px-2.5 py-1 bg-emerald-50 text-emerald-700 font-medium rounded-full border border-emerald-200">
                End-to-End Latency Target: &lt;500ms
              </span>
            </div>

            {/* Architecture Node Flowchart */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2">
              {/* Node 1: Ingestion & Storage */}
              <div
                onClick={() => setSelectedNode('storage')}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedNode === 'storage'
                    ? 'border-blue-500 bg-blue-50/70 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2 text-blue-600 mb-2">
                  <Database className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">Document Lake</span>
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Cloud Storage & Eventarc</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Automated trigger on 10-K upload. Dispatches Eventarc to Cloud Run Ingestion Worker.
                </p>
                <span className="text-[10px] font-mono text-slate-400 block mt-3">SLA: 99.99% • $0.02/GB</span>
              </div>

              {/* Node 2: Vector Search */}
              <div
                onClick={() => setSelectedNode('vector')}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedNode === 'vector'
                    ? 'border-blue-500 bg-blue-50/70 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2 text-indigo-600 mb-2">
                  <Layers className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">Vector Store</span>
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Vertex AI Vector Search</h4>
                <p className="text-xs text-slate-600 mt-1">
                  ScaNN Asymmetric Hashing (Tree-AH). Dense 768-dim embeddings with sub-10ms lookup.
                </p>
                <span className="text-[10px] font-mono text-slate-400 block mt-3">SLA: 99.9% • &lt;10ms p99</span>
              </div>

              {/* Node 3: Orchestration API */}
              <div
                onClick={() => setSelectedNode('cloudrun')}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedNode === 'cloudrun'
                    ? 'border-blue-500 bg-blue-50/70 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2 text-emerald-600 mb-2">
                  <Server className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">API Orchestration</span>
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Cloud Run Gen2 (API)</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Zero-to-1000 concurrency. min-instances=1 guarantees zero cold-start on primary gateway.
                </p>
                <span className="text-[10px] font-mono text-slate-400 block mt-3">SLA: 99.95% • Sub-30ms GW</span>
              </div>

              {/* Node 4: Generation & Evaluation */}
              <div
                onClick={() => setSelectedNode('gemini')}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  selectedNode === 'gemini'
                    ? 'border-blue-500 bg-blue-50/70 shadow-sm'
                    : 'border-slate-200 bg-slate-50 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center space-x-2 text-purple-600 mb-2">
                  <Zap className="w-5 h-5" />
                  <span className="text-xs font-bold uppercase tracking-wider">Model & Guardrails</span>
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Gemini 2.5 Pro + Safety Gate</h4>
                <p className="text-xs text-slate-600 mt-1">
                  Context Caching (50% discount) + real-time ML factual claim verification auditor.
                </p>
                <span className="text-[10px] font-mono text-slate-400 block mt-3">Managed Frontier Serving</span>
              </div>
            </div>

            {/* Detailed Inspector for Selected Node */}
            <div className="bg-slate-900 text-white rounded-xl p-5 font-sans space-y-3">
              {selectedNode === 'cloudrun' && (
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase text-emerald-400">
                      Cloud Run Gen2 (API Gateway & RAG Orchestrator)
                    </span>
                    <span className="text-xs font-mono text-slate-400">Decision: ADR-001</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mt-3">
                    <div>
                      <span className="text-slate-400 block">Cold Start Strategy</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        min-instances=1 (Keeps warm container pool for &lt;25ms gateway latency)
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Scaling Limits</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        0 to 1,000 concurrent connections per container instance
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Maintenance Burden</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        0 Kubernetes manifests, 0 node upgrades, zero cluster patching toil
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {selectedNode === 'vector' && (
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase text-indigo-400">
                      Vertex AI Vector Search (Proprietary ScaNN Engine)
                    </span>
                    <span className="text-xs font-mono text-slate-400">Decision: ADR-002</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mt-3">
                    <div>
                      <span className="text-slate-400 block">Indexing Algorithm</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Tree-AH (Asymmetric Hashing with Anisotropic Quantization)
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">ANN Recall vs Latency</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        99.2% recall at 10x higher QPS than open-source HNSW / pgvector
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Data Boundary</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        100% within Google Cloud VPC Service Controls boundary (no third-party SaaS)
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {selectedNode === 'gemini' && (
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase text-purple-400">
                      Gemini 2.5 Pro + Responsible AI Evaluation Gate
                    </span>
                    <span className="text-xs font-mono text-slate-400">Decision: ADR-003 & ADR-004</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mt-3">
                    <div>
                      <span className="text-slate-400 block">Context Caching</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Caches static 10-K filings and HR handbooks for 50% discount on input tokens
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Responsible AI Safety</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Hate speech, harassment, sexual content, and dangerous content auto-blocked
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Groundedness Gate</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Automated abstention if factual claim verification falls below 75%
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {selectedNode === 'storage' && (
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                    <span className="text-xs font-bold uppercase text-blue-400">
                      Cloud Storage Lake & Event-Driven Processing
                    </span>
                    <span className="text-xs font-mono text-slate-400">Cloud Native Ingestion</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs mt-3">
                    <div>
                      <span className="text-slate-400 block">Storage Tier</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        GCS Standard with Object Lifecycle Management to Nearline/Coldline
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Security Encryption</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Customer-Managed Encryption Keys (CMEK) via Google Cloud KMS
                      </p>
                    </div>
                    <div>
                      <span className="text-slate-400 block">Real-time Ingestion</span>
                      <p className="text-slate-200 font-semibold mt-0.5">
                        Eventarc dispatches Cloud Run Jobs to chunk and embed documents instantly
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* View 2: Architecture Decision Records (ADRs) */}
      {activeTab === 'adrs' && (
        <div className="space-y-4">
          {ARCHITECTURE_DECISION_RECORDS.map((adr) => {
            const isExpanded = expandedAdr === adr.id;
            return (
              <div
                key={adr.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
              >
                <div
                  onClick={() => setExpandedAdr(isExpanded ? '' : adr.id)}
                  className="p-5 flex items-center justify-between cursor-pointer hover:bg-slate-50/70 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <span className="px-2.5 py-1 rounded-md bg-blue-100 text-blue-800 font-mono text-xs font-bold">
                      {adr.id}
                    </span>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{adr.title}</h4>
                      <span className="text-[11px] text-slate-500">Status: {adr.status}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">
                      APPROVED
                    </span>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-400" />
                    )}
                  </div>
                </div>

                {isExpanded && (
                  <div className="p-5 pt-0 border-t border-slate-100 space-y-4 text-xs">
                    {/* VP Summary Box */}
                    <div className="p-3.5 bg-blue-50 rounded-xl border border-blue-200/60 text-blue-900 font-medium leading-relaxed">
                      {adr.vpSummary}
                    </div>

                    {/* Context & Decision */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <strong className="text-slate-800 block text-[11px] uppercase tracking-wider mb-1">
                          Business Context
                        </strong>
                        <p className="text-slate-600 leading-relaxed">{adr.context}</p>
                      </div>

                      <div>
                        <strong className="text-slate-800 block text-[11px] uppercase tracking-wider mb-1">
                          Architecture Decision
                        </strong>
                        <p className="text-slate-600 leading-relaxed font-semibold">{adr.decision}</p>
                      </div>
                    </div>

                    {/* Trade-offs table */}
                    <div>
                      <strong className="text-slate-800 block text-[11px] uppercase tracking-wider mb-2">
                        Evaluated Trade-offs
                      </strong>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {adr.tradeoffsConsidered.map((opt, i) => (
                          <div
                            key={i}
                            className={`p-3.5 rounded-xl border ${
                              opt.selected
                                ? 'bg-emerald-50/60 border-emerald-300'
                                : 'bg-slate-50 border-slate-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-bold text-slate-900">{opt.option}</span>
                              {opt.selected && (
                                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                                  SELECTED
                                </span>
                              )}
                            </div>

                            <div className="space-y-1 text-slate-600">
                              <span className="font-semibold text-slate-700 block text-[10px]">
                                Key Strengths:
                              </span>
                              <ul className="list-disc pl-4 space-y-0.5">
                                {opt.pros.map((p, j) => (
                                  <li key={j}>{p}</li>
                                ))}
                              </ul>

                              <span className="font-semibold text-slate-700 block text-[10px] pt-1">
                                Limitations:
                              </span>
                              <ul className="list-disc pl-4 space-y-0.5">
                                {opt.cons.map((c, j) => (
                                  <li key={j}>{c}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Rationale & Consequences */}
                    <div className="pt-2 border-t border-slate-100">
                      <strong className="text-slate-800 block text-[11px] uppercase tracking-wider mb-1">
                        Executive Rationale
                      </strong>
                      <p className="text-slate-600 leading-relaxed">{adr.rationale}</p>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* View 3: Terraform IaC */}
      {activeTab === 'iac' && (
        <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 text-white shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-white text-sm flex items-center">
                <FileCode className="w-4 h-4 mr-2 text-blue-400" />
                Production GCP Terraform Module (main.tf)
              </h3>
              <p className="text-xs text-slate-400">
                Provisions Cloud Storage, Vertex AI ScaNN Vector Index, Index Endpoint, and Cloud Run Gen2 service.
              </p>
            </div>
            <button
              onClick={() => handleCopy(TERRAFORM_IAC)}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center space-x-1.5 transition-colors"
            >
              {copiedCode ? (
                <>
                  <Check className="w-3.5 h-3.5" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Terraform</span>
                </>
              )}
            </button>
          </div>

          <pre className="p-4 bg-slate-950 rounded-xl overflow-x-auto text-xs font-mono text-emerald-400 leading-relaxed max-h-[500px]">
            {TERRAFORM_IAC}
          </pre>
        </div>
      )}
    </div>
  );
};
