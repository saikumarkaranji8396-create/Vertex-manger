import React, { useState } from 'react';
import {
  Search,
  Sparkles,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Layers,
  ChevronRight,
  RefreshCw,
  ExternalLink,
  SlidersHorizontal,
  Bookmark,
  Zap,
} from 'lucide-react';
import { RAGQueryResponse, RetrievalResult } from '../types';

interface RAGStudioProps {
  onExecuteQuery: (query: string, useStreaming: boolean) => Promise<RAGQueryResponse | null>;
  currentResult: RAGQueryResponse | null;
  loading: boolean;
  streamingStatus: string | null;
  streamingTokens: string;
}

const SAMPLE_QUERIES = [
  {
    category: '10-K Financials',
    label: 'Cloud Revenue & Operating Income',
    query: 'What was Google Cloud revenue, operating income, and YoY growth in 2023, and how did it compare to 2022?',
  },
  {
    category: '10-K Financials',
    label: 'AI Data Center Power & CapEx Risks',
    query: 'What risks does Alphabet identify regarding data center electrical power and cooling infrastructure for generative AI?',
  },
  {
    category: 'HR & Policy',
    label: 'Hybrid Work & Sabbatical Rules',
    query: 'What are the required in-office days under the hybrid work policy, and what is the Work From Anywhere (WFA) allowance?',
  },
  {
    category: 'HR & Policy',
    label: 'Equity Vesting & Refresher Grants',
    query: 'Explain the vesting schedule for initial RSU grants versus annual performance refresher equity.',
  },
  {
    category: 'GCP Specs',
    label: 'Vertex Vector Search & ScaNN Latency',
    query: 'Why does Vertex AI Vector Search use the ScaNN algorithm instead of HNSW, and what are its SLA guarantees?',
  },
  {
    category: 'GCP Specs',
    label: 'Prompt Caching Economics on Vertex',
    query: 'How does Vertex AI Context Caching work for Gemini models, and what are the cost reduction benefits?',
  },
];

export const RAGStudio: React.FC<RAGStudioProps> = ({
  onExecuteQuery,
  currentResult,
  loading,
  streamingStatus,
  streamingTokens,
}) => {
  const [query, setQuery] = useState(
    'What was Google Cloud revenue, operating income, and YoY growth in 2023, and how did it compare to 2022?'
  );
  const [useStreaming, setUseStreaming] = useState(true);
  const [activeChunkModal, setActiveChunkModal] = useState<RetrievalResult | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || loading) return;
    onExecuteQuery(query.trim(), useStreaming);
  };

  const handleSelectSample = (sampleQuery: string) => {
    setQuery(sampleQuery);
    onExecuteQuery(sampleQuery, useStreaming);
  };

  // Format text with interactive citations
  const renderFormattedAnswer = (text: string) => {
    if (!text) return null;

    // Split text by citation brackets like [Chunk 1], [Chunk 2]
    const parts = text.split(/(\[Chunk \d+\])/g);

    return parts.map((part, i) => {
      const match = part.match(/\[Chunk (\d+)\]/);
      if (match) {
        const chunkIndex = parseInt(match[1], 10);
        const retrievedChunk = currentResult?.retrievedChunks?.[chunkIndex - 1];

        return (
          <button
            key={i}
            onClick={() => retrievedChunk && setActiveChunkModal(retrievedChunk)}
            className="inline-flex items-center px-1.5 py-0.5 mx-0.5 text-xs font-mono font-semibold rounded bg-blue-100 text-blue-800 hover:bg-blue-200 border border-blue-300 transition-colors cursor-pointer"
            title={`Click to inspect source chunk #${chunkIndex} in vector store`}
          >
            <Bookmark className="w-3 h-3 mr-0.5 text-blue-600" />
            {part}
          </button>
        );
      }

      // Format bold markdown
      if (part.includes('**')) {
        const subParts = part.split(/(\*\*.*?\*\*)/g);
        return (
          <span key={i}>
            {subParts.map((sp, j) => {
              if (sp.startsWith('**') && sp.endsWith('**')) {
                return (
                  <strong key={j} className="font-semibold text-slate-900">
                    {sp.slice(2, -2)}
                  </strong>
                );
              }
              return sp;
            })}
          </span>
        );
      }

      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="space-y-6">
      {/* Search Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full flex items-center">
                <Zap className="w-3 h-3 mr-1 text-blue-400" /> Retrieval-Augmented Generation
              </span>
              <span className="text-xs text-slate-400">Vertex AI ScaNN + Gemini 2.5 Pro</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight mt-2 text-white">
              Enterprise Document Q&A Engine
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              Real-time vector similarity search over SEC 10-K disclosures, corporate HR policies,
              and Google Cloud architectural SLA documentation with grounded citation verification.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs">
            <div className="bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700">
              <span className="text-slate-400 block">Orchestration</span>
              <span className="text-white font-semibold flex items-center">
                <span className="w-2 h-2 rounded-full bg-emerald-400 mr-1.5"></span> Cloud Run Gen2
              </span>
            </div>
            <div className="bg-slate-800/80 px-3 py-2 rounded-xl border border-slate-700">
              <span className="text-slate-400 block">Vector Index</span>
              <span className="text-white font-semibold">Vertex Vector Search</span>
            </div>
          </div>
        </div>

        {/* Query Input Bar */}
        <form onSubmit={handleSubmit} className="mt-6">
          <div className="relative flex items-center">
            <div className="absolute left-4 text-slate-400">
              <Search className="w-5 h-5 text-blue-400" />
            </div>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Ask anything regarding Alphabet 10-K, enterprise policies, or GCP specifications..."
              className="w-full pl-12 pr-36 py-3.5 bg-slate-800/90 text-white placeholder-slate-400 rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base font-normal shadow-inner"
            />
            <div className="absolute right-2.5 flex items-center space-x-2">
              <button
                type="submit"
                disabled={loading || !query.trim()}
                className="px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm font-semibold transition-all shadow-md shadow-blue-600/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-1.5"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Run Query</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Controls row */}
          <div className="flex flex-wrap items-center justify-between gap-3 mt-3 text-xs text-slate-400">
            <div className="flex items-center space-x-4">
              <label className="flex items-center space-x-1.5 cursor-pointer text-slate-300 hover:text-white">
                <input
                  type="checkbox"
                  checked={useStreaming}
                  onChange={(e) => setUseStreaming(e.target.checked)}
                  className="rounded border-slate-700 text-blue-600 focus:ring-blue-500"
                />
                <span>Enable Real-time SSE Token Streaming</span>
              </label>
              <span className="text-slate-600">•</span>
              <span className="text-slate-400">Hybrid Search: Dense (ScaNN) + BM25 Lexical (RRF)</span>
            </div>
            <div className="text-slate-400 font-mono text-[11px]">
              Top-K Chunks: 4 • Temperature: 0.2
            </div>
          </div>
        </form>

        {/* Sample Prompt Pills */}
        <div className="mt-4 pt-4 border-t border-slate-800/80">
          <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center">
            <SlidersHorizontal className="w-3.5 h-3.5 mr-1.5 text-blue-400" />
            Benchmark Queries for Evaluation:
          </div>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_QUERIES.map((sq, i) => (
              <button
                key={i}
                onClick={() => handleSelectSample(sq.query)}
                className="text-left px-3 py-1.5 rounded-lg bg-slate-800/70 hover:bg-slate-700 border border-slate-700/70 text-xs text-slate-300 hover:text-white transition-colors flex items-center space-x-1.5 group"
              >
                <span className="font-semibold text-blue-400 text-[10px] uppercase">
                  {sq.category.split(' ')[0]}
                </span>
                <span>{sq.label}</span>
                <ChevronRight className="w-3 h-3 text-slate-500 group-hover:text-white transition-transform group-hover:translate-x-0.5" />
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Results Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 7 Columns: Grounded Answer & Latency */}
        <div className="lg:col-span-7 space-y-6">
          {/* Answer Card */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
              <div className="flex items-center space-x-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
                <h3 className="font-semibold text-slate-800 text-sm">
                  Grounded Generative Answer
                </h3>
                <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-700 font-mono rounded border border-blue-200">
                  {currentResult?.model || 'Gemini 2.5 Pro'}
                </span>
              </div>

              {currentResult && (
                <div className="flex items-center space-x-2 text-xs">
                  <span
                    className={`px-2.5 py-1 rounded-full font-medium flex items-center ${
                      currentResult.responsibleAIFilters.groundednessGatePassed
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-amber-50 text-amber-700 border border-amber-200'
                    }`}
                  >
                    <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                    Groundedness:{' '}
                    {currentResult.responsibleAIFilters.groundednessGatePassed
                      ? 'VERIFIED'
                      : 'FLAGGED'}
                  </span>
                </div>
              )}
            </div>

            <div className="p-6">
              {loading && !streamingTokens && (
                <div className="py-12 text-center space-y-3">
                  <div className="inline-flex p-3 rounded-full bg-blue-50 text-blue-600 animate-bounce">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <p className="text-sm font-medium text-slate-700">
                    {streamingStatus || 'Executing hybrid retrieval across Vertex Vector Search...'}
                  </p>
                  <p className="text-xs text-slate-400">
                    ScaNN dense embeddings + BM25 keyword fusion in progress
                  </p>
                </div>
              )}

              {/* Streaming Output or Finished Result */}
              {(streamingTokens || currentResult) && (
                <div className="prose prose-slate max-w-none text-sm leading-relaxed text-slate-700 space-y-4">
                  {streamingTokens && !currentResult ? (
                    <div className="whitespace-pre-wrap font-sans">
                      {streamingTokens}
                      <span className="inline-block w-2 h-4 bg-blue-600 ml-1 animate-pulse"></span>
                    </div>
                  ) : (
                    currentResult && (
                      <div className="whitespace-pre-wrap font-sans">
                        {renderFormattedAnswer(currentResult.answer)}
                      </div>
                    )
                  )}
                </div>
              )}

              {!loading && !currentResult && !streamingTokens && (
                <div className="py-12 text-center text-slate-400 text-sm">
                  Run a query above or click a benchmark sample to observe real-time RAG inference.
                </div>
              )}
            </div>

            {/* Latency Waterfall Footer */}
            {currentResult && (
              <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
                <div className="flex items-center space-x-3 text-slate-500">
                  <span className="flex items-center font-medium text-slate-700">
                    <Clock className="w-3.5 h-3.5 mr-1 text-slate-400" />
                    Latency Waterfall:
                  </span>
                  <span className="font-mono text-slate-600">
                    Index: {currentResult.latency.vectorSearchMs}ms
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="font-mono text-slate-600">
                    LLM: {currentResult.latency.generationMs}ms
                  </span>
                  <span className="text-slate-300">•</span>
                  <span className="font-mono text-slate-600">
                    Audit: {currentResult.latency.evaluationMs}ms
                  </span>
                </div>
                <div className="font-semibold text-slate-900 font-mono bg-white px-2.5 py-1 rounded border border-slate-200">
                  Total: {currentResult.latency.totalMs}ms
                </div>
              </div>
            )}
          </div>

          {/* Responsible AI & Evaluation Summary Snapshot */}
          {currentResult && (
            <div className="bg-slate-50/80 rounded-2xl p-5 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center">
                  <ShieldCheck className="w-4 h-4 mr-1 text-blue-600" />
                  Responsible AI Audit & RAG Triad Snapshot
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-800">
                  Composite Score: {currentResult.evaluation.compositeQualityScore}%
                </span>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-white p-3 rounded-xl border border-slate-200/60 text-center">
                  <span className="text-[11px] text-slate-500 block">Faithfulness</span>
                  <span className="text-lg font-bold text-emerald-600 font-mono">
                    {currentResult.evaluation.faithfulnessScore}%
                  </span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-200/60 text-center">
                  <span className="text-[11px] text-slate-500 block">Context Relevance</span>
                  <span className="text-lg font-bold text-blue-600 font-mono">
                    {currentResult.evaluation.contextRelevanceScore}%
                  </span>
                </div>
                <div className="bg-white p-3 rounded-xl border border-slate-200/60 text-center">
                  <span className="text-[11px] text-slate-500 block">Answer Relevance</span>
                  <span className="text-lg font-bold text-indigo-600 font-mono">
                    {currentResult.evaluation.answerRelevanceScore}%
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-600 italic bg-white p-3 rounded-xl border border-slate-200/60">
                "{currentResult.evaluation.evaluationSummary}"
              </p>
            </div>
          )}
        </div>

        {/* Right 5 Columns: Retrieved Chunks & Vector Provenance */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900 text-sm flex items-center">
              <Layers className="w-4 h-4 mr-1.5 text-blue-600" />
              Retrieved Context Vectors ({currentResult?.retrievedChunks?.length || 0})
            </h3>
            <span className="text-xs text-slate-500">Reciprocal Rank Fusion</span>
          </div>

          {currentResult?.retrievedChunks && currentResult.retrievedChunks.length > 0 ? (
            <div className="space-y-3">
              {currentResult.retrievedChunks.map((res, idx) => (
                <div
                  key={res.chunk.id}
                  onClick={() => setActiveChunkModal(res)}
                  className="bg-white rounded-xl p-4 border border-slate-200 hover:border-blue-400 hover:shadow-md transition-all cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-mono text-xs font-bold flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <span className="text-xs font-semibold text-slate-800 line-clamp-1 group-hover:text-blue-600 transition-colors">
                        {res.chunk.documentTitle}
                      </span>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
                      {res.chunk.category}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 line-clamp-3 mb-2 font-mono leading-relaxed bg-slate-50 p-2.5 rounded-lg border border-slate-100">
                    {res.chunk.text}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 font-mono pt-1 border-t border-slate-100">
                    <span>Hybrid RRF: {res.hybridScore}</span>
                    <span>BM25: {res.bm25Score}</span>
                    <span>Dense Cos: {res.similarityScore}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-slate-50 rounded-xl p-8 border border-dashed border-slate-300 text-center text-slate-400 text-xs">
              Retrieved vector chunks and provenance metadata will appear here after query execution.
            </div>
          )}
        </div>
      </div>

      {/* Chunk Inspection Modal */}
      {activeChunkModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-md bg-blue-600 text-white font-mono text-xs font-bold">
                  Chunk #{activeChunkModal.rank}
                </span>
                <h4 className="font-bold text-slate-900 text-base line-clamp-1">
                  {activeChunkModal.chunk.documentTitle}
                </h4>
              </div>
              <button
                onClick={() => setActiveChunkModal(null)}
                className="text-slate-400 hover:text-slate-700 text-lg font-bold px-2 py-1"
              >
                ✕
              </button>
            </div>

            <div className="py-4 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[10px]">Chunk ID</span>
                  <span className="font-semibold text-slate-700">{activeChunkModal.chunk.id}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[10px]">Tokens</span>
                  <span className="font-semibold text-slate-700">~{activeChunkModal.chunk.tokenCount}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[10px]">Dense Cosine</span>
                  <span className="font-semibold text-emerald-600">{activeChunkModal.similarityScore}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-200/60">
                  <span className="text-slate-400 block text-[10px]">Hybrid RRF</span>
                  <span className="font-semibold text-blue-600">{activeChunkModal.hybridScore}</span>
                </div>
              </div>

              <div>
                <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Ground Truth Chunk Passage Text
                </h5>
                <div className="p-4 bg-slate-900 text-slate-200 rounded-xl font-mono text-xs leading-relaxed overflow-x-auto whitespace-pre-wrap">
                  {activeChunkModal.chunk.text}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setActiveChunkModal(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-lg"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
