import React, { useState, useMemo } from 'react';
import {
  Calculator,
  TrendingUp,
  Server,
  Cloud,
  DollarSign,
  Zap,
  HelpCircle,
  Award,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { CostParameters } from '../types';
import { calculateTCO } from '../data/adrsAndCost';

export const CostCalculator: React.FC = () => {
  const [params, setParams] = useState<CostParameters>({
    queriesPerMonth: 120_000,
    avgInputTokens: 2_400,
    avgOutputTokens: 450,
    corpusSizeGB: 15,
    vectorCount: 25_000,
    promptCacheRate: 0.65, // 65% cache hit rate
    monthlyGrowthRate: 10,
  });

  const comparison = useMemo(() => calculateTCO(params), [params]);

  // Generate curve data points for break-even chart
  const chartData = useMemo(() => {
    const points = [10_000, 50_000, 100_000, 200_000, 350_000, 500_000, 750_000, 1_000_000];
    return points.map((q) => {
      const calc = calculateTCO({ ...params, queriesPerMonth: q });
      return {
        queries: `${(q / 1000).toFixed(0)}k`,
        serverless: Math.round(calc.serverless.totalMonthlyCost),
        gke: Math.round(calc.gke.totalMonthlyCost),
      };
    });
  }, [params]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white border border-slate-800 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 text-xs font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-full flex items-center">
                <Award className="w-3.5 h-3.5 mr-1 text-blue-400" /> Generative AI Leader VP Differentiator
              </span>
              <span className="text-xs text-slate-400">Total Cost of Ownership (TCO) & Sizing Model</span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight mt-2 text-white">
              Serverless Cloud Run vs. GKE Economics
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-3xl">
              Definitive cost/latency trade-off analysis comparing fully managed serverless orchestration
              (Cloud Run + Vertex AI) against self-hosted Kubernetes GPU clusters.
            </p>
          </div>

          <div className="bg-slate-800/90 px-4 py-3 rounded-xl border border-slate-700 text-right">
            <span className="text-xs text-slate-400 block">Calculated Break-Even Point</span>
            <span className="text-xl font-bold text-amber-400 font-mono">
              ~{(comparison.breakEvenMonthlyQueries / 1000).toFixed(0)}k queries/mo
            </span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Below this, Serverless wins decisively</span>
          </div>
        </div>

        {/* Executive Summary Callout */}
        <div className="mt-6 p-4 rounded-xl bg-blue-900/30 border border-blue-500/30 text-xs text-blue-200 leading-relaxed flex items-start space-x-3">
          <div className="p-1 rounded bg-blue-500/20 shrink-0 text-blue-300">
            <TrendingUp className="w-4 h-4" />
          </div>
          <div>
            <strong className="font-semibold text-white">VP Architecture Strategy: </strong>
            At your current volume of {params.queriesPerMonth.toLocaleString()} queries/month, Cloud Run Serverless saves{' '}
            <strong className="text-emerald-300 font-mono">
              ${(comparison.gke.totalMonthlyCost - comparison.serverless.totalMonthlyCost).toFixed(0)}/month
            </strong>{' '}
            ({Math.round(((comparison.gke.totalMonthlyCost - comparison.serverless.totalMonthlyCost) / comparison.gke.totalMonthlyCost) * 100)}% lower TCO)
            while eliminating Kubernetes cluster toil and guaranteeing sub-second response times.
          </div>
        </div>
      </div>

      {/* Main Grid: Controls & Comparison */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left 4 Cols: Interactive Parameter Sliders */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-5">
          <h3 className="font-bold text-slate-900 text-sm flex items-center">
            <Calculator className="w-4 h-4 mr-1.5 text-blue-600" />
            Workload Sizing Parameters
          </h3>

          {/* Queries per month */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate-700">Monthly Query Volume</span>
              <span className="font-mono font-bold text-blue-600">
                {params.queriesPerMonth.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={10_000}
              max={1_000_000}
              step={10_000}
              value={params.queriesPerMonth}
              onChange={(e) =>
                setParams({ ...params, queriesPerMonth: parseInt(e.target.value, 10) })
              }
              className="w-full accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>10k</span>
              <span>500k</span>
              <span>1M/mo</span>
            </div>
          </div>

          {/* Input Tokens */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate-700">Avg Input Tokens (Context + Query)</span>
              <span className="font-mono font-bold text-slate-800">
                {params.avgInputTokens.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={500}
              max={8_000}
              step={100}
              value={params.avgInputTokens}
              onChange={(e) =>
                setParams({ ...params, avgInputTokens: parseInt(e.target.value, 10) })
              }
              className="w-full accent-blue-600"
            />
            <span className="text-[10px] text-slate-400 block">~4-5 retrieved chunks per query</span>
          </div>

          {/* Output Tokens */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate-700">Avg Output Tokens</span>
              <span className="font-mono font-bold text-slate-800">
                {params.avgOutputTokens.toLocaleString()}
              </span>
            </div>
            <input
              type="range"
              min={150}
              max={1_500}
              step={50}
              value={params.avgOutputTokens}
              onChange={(e) =>
                setParams({ ...params, avgOutputTokens: parseInt(e.target.value, 10) })
              }
              className="w-full accent-blue-600"
            />
          </div>

          {/* Prompt Caching Rate */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate-700">Vertex Context Caching Hit Rate</span>
              <span className="font-mono font-bold text-emerald-600">
                {Math.round(params.promptCacheRate * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={0.9}
              step={0.05}
              value={params.promptCacheRate}
              onChange={(e) =>
                setParams({ ...params, promptCacheRate: parseFloat(e.target.value) })
              }
              className="w-full accent-emerald-600"
            />
            <span className="text-[10px] text-slate-400 block">50% discount on cached 10-K & policy tokens</span>
          </div>

          {/* Corpus Size */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="font-medium text-slate-700">Document Lake Size (GB)</span>
              <span className="font-mono font-bold text-slate-800">
                {params.corpusSizeGB} GB
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={100}
              step={1}
              value={params.corpusSizeGB}
              onChange={(e) =>
                setParams({ ...params, corpusSizeGB: parseInt(e.target.value, 10) })
              }
              className="w-full accent-blue-600"
            />
          </div>
        </div>

        {/* Right 8 Cols: Side-by-Side Cards & Break-Even Chart */}
        <div className="lg:col-span-8 space-y-6">
          {/* Comparison Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Serverless Card */}
            <div className="bg-white rounded-2xl p-6 border-2 border-blue-500 shadow-md relative">
              <div className="absolute -top-3 right-4 bg-blue-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                Recommended Choice
              </div>

              <div className="flex items-center space-x-2 mb-3">
                <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
                  <Cloud className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Serverless GCP Stack</h4>
                  <span className="text-[11px] text-slate-500">Cloud Run Gen2 + Vertex AI</span>
                </div>
              </div>

              <div className="my-4 pb-4 border-b border-slate-100">
                <span className="text-xs text-slate-500 block">Total Monthly Operating Cost</span>
                <div className="flex items-baseline space-x-2 mt-1">
                  <span className="text-3xl font-extrabold text-slate-900 font-mono">
                    ${comparison.serverless.totalMonthlyCost.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-500">/ month</span>
                </div>
                <div className="text-xs font-mono text-blue-600 font-semibold mt-1">
                  ${comparison.serverless.costPerQuery.toFixed(4)} per query
                </div>
              </div>

              {/* Itemized list */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Gemini 2.5 Pro Inference:</span>
                  <span className="font-mono font-medium">${comparison.serverless.modelInferenceCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Vertex Vector Search (ScaNN):</span>
                  <span className="font-mono font-medium">${comparison.serverless.vectorSearchCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Cloud Run Compute (min-instances=1):</span>
                  <span className="font-mono font-medium">${comparison.serverless.computeCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Cloud Storage & Networking:</span>
                  <span className="font-mono font-medium">
                    ${(comparison.serverless.storageCost + comparison.serverless.networkCost).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>DevOps / SRE Maintenance (0.05 FTE):</span>
                  <span className="font-mono font-medium">${comparison.serverless.devOpsFteCost.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="flex items-center text-emerald-600 font-medium">
                  <Check className="w-3.5 h-3.5 mr-1" /> 0 Kubernetes toil
                </span>
                <span className="font-mono">p50: ~{comparison.latencyP50ServerlessMs}ms</span>
              </div>
            </div>

            {/* GKE Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm relative">
              <div className="flex items-center space-x-2 mb-3">
                <div className="p-2 rounded-xl bg-slate-100 text-slate-600">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base">Self-Hosted GKE Cluster</h4>
                  <span className="text-[11px] text-slate-500">2x L4 GPU Nodes + vLLM + Qdrant</span>
                </div>
              </div>

              <div className="my-4 pb-4 border-b border-slate-100">
                <span className="text-xs text-slate-500 block">Total Monthly Operating Cost</span>
                <div className="flex items-baseline space-x-2 mt-1">
                  <span className="text-3xl font-extrabold text-slate-900 font-mono">
                    ${comparison.gke.totalMonthlyCost.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-500">/ month</span>
                </div>
                <div className="text-xs font-mono text-slate-500 font-semibold mt-1">
                  ${comparison.gke.costPerQuery.toFixed(4)} per query
                </div>
              </div>

              {/* Itemized list */}
              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-600">
                  <span>Dedicated GPU Nodes (2x L4):</span>
                  <span className="font-mono font-medium">${comparison.gke.modelInferenceCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Self-Hosted Vector DB on Nodes:</span>
                  <span className="font-mono font-medium">${comparison.gke.vectorSearchCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>GKE Cluster Management Fee:</span>
                  <span className="font-mono font-medium">${comparison.gke.computeCost.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Storage SSD Persistent Disks:</span>
                  <span className="font-mono font-medium">
                    ${(comparison.gke.storageCost + comparison.gke.networkCost).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>SRE / K8s Maintenance (0.35 FTE):</span>
                  <span className="font-mono font-medium">${comparison.gke.devOpsFteCost.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                <span className="text-amber-600 font-medium">High Fixed Baseline</span>
                <span className="font-mono">p50: ~{comparison.latencyP50GkeMs}ms</span>
              </div>
            </div>
          </div>

          {/* Break-Even Curve Chart */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pb-2 border-b border-slate-100 gap-1">
              <div>
                <h4 className="font-bold text-slate-900 text-sm">
                  Monthly Cost Scaling & Break-Even Curve
                </h4>
                <p className="text-xs text-slate-500">
                  Inflection point showing where fixed GPU hardware cost intersects with serverless token pricing.
                </p>
              </div>
              <div className="flex items-center space-x-4 text-xs font-mono">
                <span className="flex items-center text-blue-600">
                  <span className="w-3 h-3 rounded-full bg-blue-600 mr-1.5"></span> Serverless
                </span>
                <span className="flex items-center text-slate-600">
                  <span className="w-3 h-3 rounded-full bg-slate-500 mr-1.5"></span> GKE Fixed
                </span>
              </div>
            </div>

            <div className="h-64 w-full pt-4">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="queries" tick={{ fontSize: 11 }} />
                  <YAxis
                    tickFormatter={(val) => `$${val}`}
                    tick={{ fontSize: 11 }}
                  />
                  <Tooltip
                    formatter={(value: any) => [`$${value.toLocaleString()}`, 'Monthly Cost']}
                  />
                  <Line
                    type="monotone"
                    dataKey="serverless"
                    name="Serverless Cloud Run"
                    stroke="#2563eb"
                    strokeWidth={3}
                    dot={{ r: 4 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="gke"
                    name="GKE Self-Hosted"
                    stroke="#64748b"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    dot={{ r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs text-slate-600 leading-relaxed">
              <strong className="text-slate-800">Architectural Decision Takeaway: </strong>
              For workloads below ~{(comparison.breakEvenMonthlyQueries / 1000).toFixed(0)}k queries/month, Serverless Cloud Run + Vertex AI eliminates over $45,000/year in idle GPU reservations and Kubernetes maintenance toil. GKE only becomes viable when sustained, 24/7 high-concurrency throughput amortizes dedicated GPU hardware.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
