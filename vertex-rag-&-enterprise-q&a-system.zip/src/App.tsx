import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { RAGStudio } from './components/RAGStudio';
import { EvaluationPanel } from './components/EvaluationPanel';
import { CostCalculator } from './components/CostCalculator';
import { VectorLake } from './components/VectorLake';
import { ArchitectureView } from './components/ArchitectureView';
import { DocumentItem, RAGQueryResponse } from './types';
import { INITIAL_DOCUMENTS } from './data/defaultCorpus';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('rag');
  const [documents, setDocuments] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [loadingDocs, setLoadingDocs] = useState<boolean>(false);
  const [currentResult, setCurrentResult] = useState<RAGQueryResponse | null>(null);
  const [loadingQuery, setLoadingQuery] = useState<boolean>(false);
  const [streamingStatus, setStreamingStatus] = useState<string | null>(null);
  const [streamingTokens, setStreamingTokens] = useState<string>('');
  const [benchmarkResults, setBenchmarkResults] = useState<any[] | null>(null);
  const [benchmarkLoading, setBenchmarkLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Fetch initial documents from server API
  const fetchDocuments = async () => {
    try {
      setLoadingDocs(true);
      const res = await fetch('/api/documents');
      if (res.ok) {
        const data = await res.json();
        if (data.documents && data.documents.length > 0) {
          setDocuments(data.documents);
        }
      }
    } catch (err: any) {
      console.warn('Unable to fetch live documents, using fallback in-memory dataset:', err.message);
    } finally {
      setLoadingDocs(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  // Execute RAG Query with optional SSE streaming
  const handleExecuteQuery = async (query: string, useStreaming: boolean): Promise<RAGQueryResponse | null> => {
    setLoadingQuery(true);
    setErrorMessage(null);
    setStreamingTokens('');
    setStreamingStatus('Initializing query embedding and ScaNN vector search...');

    if (useStreaming) {
      return new Promise((resolve) => {
        const eventSource = new EventSource(`/api/rag/stream?q=${encodeURIComponent(query)}`);

        eventSource.addEventListener('status', (e: MessageEvent) => {
          try {
            const data = JSON.parse(e.data);
            setStreamingStatus(data.message);
          } catch {}
        });

        eventSource.addEventListener('token', (e: MessageEvent) => {
          try {
            const data = JSON.parse(e.data);
            setStreamingTokens((prev) => prev + data.token);
          } catch {}
        });

        eventSource.addEventListener('complete', (e: MessageEvent) => {
          try {
            const result: RAGQueryResponse = JSON.parse(e.data);
            setCurrentResult(result);
            setLoadingQuery(false);
            setStreamingTokens('');
            setStreamingStatus(null);
            eventSource.close();
            resolve(result);
          } catch (err: any) {
            console.error('Failed to parse streaming response', err);
            setLoadingQuery(false);
            eventSource.close();
            resolve(null);
          }
        });

        eventSource.addEventListener('error', (e) => {
          console.warn('SSE stream error, falling back to standard POST /api/rag/query', e);
          eventSource.close();
          // Fallback to non-streaming POST
          executeNonStreaming(query).then(resolve);
        });
      });
    } else {
      return executeNonStreaming(query);
    }
  };

  const executeNonStreaming = async (query: string): Promise<RAGQueryResponse | null> => {
    try {
      const res = await fetch('/api/rag/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, topK: 4 }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `HTTP error ${res.status}`);
      }

      const result: RAGQueryResponse = await res.json();
      setCurrentResult(result);
      return result;
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to execute query.');
      return null;
    } finally {
      setLoadingQuery(false);
      setStreamingTokens('');
      setStreamingStatus(null);
    }
  };

  // Ingest document
  const handleIngestDocument = async (doc: {
    title: string;
    category: DocumentItem['category'];
    source: string;
    content: string;
  }) => {
    try {
      const res = await fetch('/api/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(doc),
      });
      if (res.ok) {
        await fetchDocuments();
      }
    } catch (err: any) {
      console.error('Failed to ingest document:', err);
    }
  };

  // Delete document
  const handleDeleteDocument = async (id: string) => {
    try {
      const res = await fetch(`/api/documents/${id}`, { method: 'DELETE' });
      if (res.ok) {
        await fetchDocuments();
      }
    } catch (err: any) {
      console.error('Failed to delete document:', err);
    }
  };

  // Run automated benchmark
  const handleRunBenchmark = async (): Promise<any[]> => {
    setBenchmarkLoading(true);
    try {
      const res = await fetch('/api/eval/benchmark', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        setBenchmarkResults(data.benchmarkResults);
        return data.benchmarkResults;
      }
      return [];
    } catch (err: any) {
      console.error('Benchmark execution error:', err);
      return [];
    } finally {
      setBenchmarkLoading(false);
    }
  };

  // Total chunk count
  const totalChunks = documents.reduce((acc, d) => acc + (d.chunks?.length || d.chunkCount || 0), 0);

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 font-sans antialiased flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        documentCount={documents.length}
        chunkCount={totalChunks}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center justify-between">
            <span>{errorMessage}</span>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-500 font-bold px-2"
            >
              ✕
            </button>
          </div>
        )}

        {activeTab === 'rag' && (
          <RAGStudio
            onExecuteQuery={handleExecuteQuery}
            currentResult={currentResult}
            loading={loadingQuery}
            streamingStatus={streamingStatus}
            streamingTokens={streamingTokens}
          />
        )}

        {activeTab === 'eval' && (
          <EvaluationPanel
            evaluation={currentResult?.evaluation || null}
            lastQuery={currentResult?.query}
            onRunBenchmark={handleRunBenchmark}
            benchmarkResults={benchmarkResults}
            benchmarkLoading={benchmarkLoading}
          />
        )}

        {activeTab === 'vector' && (
          <VectorLake
            documents={documents}
            onIngestDocument={handleIngestDocument}
            onDeleteDocument={handleDeleteDocument}
            loading={loadingDocs}
          />
        )}

        {activeTab === 'cost' && <CostCalculator />}

        {activeTab === 'architecture' && <ArchitectureView />}
      </main>

      {/* Enterprise Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 mt-auto text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="font-semibold text-slate-800">Vertex RAG Backend</span>
            <span>•</span>
            <span>Gemini 2.5 Pro Foundation Serving</span>
            <span>•</span>
            <span>Vertex Vector Search (ScaNN)</span>
          </div>
          <div className="flex items-center space-x-4 font-mono text-[11px] text-slate-400">
            <span>Orchestration: Google Cloud Run Gen2</span>
            <span>Security: VPC-SC + CMEK</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
