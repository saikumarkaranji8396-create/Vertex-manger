export interface DocumentItem {
  id: string;
  title: string;
  category: '10-K Financials' | 'HR & Policy' | 'GCP Docs' | 'Custom Ingestion';
  source: string;
  date: string;
  totalTokens: number;
  chunkCount: number;
  content: string;
  chunks: DocumentChunk[];
}

export interface DocumentChunk {
  id: string;
  documentId: string;
  documentTitle: string;
  category: string;
  chunkIndex: number;
  text: string;
  tokenCount: number;
  embedding?: number[];
}

export interface RetrievalResult {
  chunk: DocumentChunk;
  similarityScore: number;
  bm25Score: number;
  hybridScore: number;
  rank: number;
}

export interface FactualClaim {
  claim: string;
  verdict: 'grounded' | 'extrapolated' | 'hallucination';
  confidence: number;
  sourceChunkIndex?: number;
  reasoning: string;
}

export interface RAGEvalMetrics {
  contextRelevanceScore: number; // 0-100
  faithfulnessScore: number;      // 0-100
  answerRelevanceScore: number;   // 0-100
  compositeQualityScore: number;  // 0-100
  hallucinationDetected: boolean;
  factualClaims: FactualClaim[];
  evaluationSummary: string;
  evaluatorLatencyMs: number;
}

export interface LatencyBreakdown {
  queryEmbeddingMs: number;
  vectorSearchMs: number;
  generationMs: number;
  evaluationMs: number;
  totalMs: number;
}

export interface RAGQueryResponse {
  query: string;
  answer: string;
  model: string;
  retrievedChunks: RetrievalResult[];
  evaluation: RAGEvalMetrics;
  latency: LatencyBreakdown;
  tokenUsage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
    cachedTokens?: number;
  };
  responsibleAIFilters: {
    piiClean: boolean;
    groundednessGatePassed: boolean;
    toxicityScore: number;
    guardrailAction: 'APPROVED' | 'FLAGGED' | 'SANITIZED';
  };
}

export interface CostParameters {
  queriesPerMonth: number;
  avgInputTokens: number;
  avgOutputTokens: number;
  corpusSizeGB: number;
  vectorCount: number;
  promptCacheRate: number; // 0 to 1
  monthlyGrowthRate: number; // %
}

export interface CostBreakdown {
  modelInferenceCost: number;
  vectorSearchCost: number;
  computeCost: number;
  storageCost: number;
  networkCost: number;
  devOpsFteCost: number;
  totalMonthlyCost: number;
  costPerQuery: number;
  annualTCO: number;
}

export interface ArchitectureComparison {
  serverless: CostBreakdown;
  gke: CostBreakdown;
  breakEvenMonthlyQueries: number;
  latencyP50ServerlessMs: number;
  latencyP50GkeMs: number;
  coldStartRisk: string;
  operationalComplexity: 'Low' | 'Medium' | 'High';
}

export interface ADR {
  id: string;
  title: string;
  status: 'ACCEPTED' | 'PROPOSED' | 'SUPERSEDED';
  context: string;
  decision: string;
  tradeoffsConsidered: { option: string; pros: string[]; cons: string[]; selected: boolean }[];
  rationale: string;
  consequences: string[];
  vpSummary: string;
}

export interface BenchmarkTestCase {
  id: string;
  category: string;
  question: string;
  groundTruthKeywords: string[];
  lastResult?: {
    faithfulness: number;
    contextRelevance: number;
    latencyMs: number;
    passed: boolean;
  };
}
