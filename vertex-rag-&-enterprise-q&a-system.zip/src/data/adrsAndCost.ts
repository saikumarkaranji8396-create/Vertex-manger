import { ADR, CostParameters, CostBreakdown, ArchitectureComparison, BenchmarkTestCase } from '../types';

export const ARCHITECTURE_DECISION_RECORDS: ADR[] = [
  {
    id: 'ADR-001',
    title: 'Selection of Cloud Run (Serverless) over GKE for Enterprise RAG Orchestration',
    status: 'ACCEPTED',
    context: 'The enterprise requires a real-time document Q&A and vector retrieval API serving business users. Expected query traffic is bursty during business hours (9 AM - 6 PM EST) with significant drops overnight and weekends. We evaluated Google Kubernetes Engine (GKE Autopilot/Standard) versus Google Cloud Run Gen2.',
    decision: 'Deploy the RAG orchestration API on Google Cloud Run Gen2 with min-instances=1 in primary region (us-central1) and automatic scale-to-zero for non-production environments.',
    tradeoffsConsidered: [
      {
        option: 'Google Cloud Run (Serverless)',
        selected: true,
        pros: [
          'Zero cluster maintenance overhead and zero node provisioning toil (0 FTE devops required)',
          'True per-millisecond billing with sub-second scale-from-zero (min-instances=1 guarantees <30ms gateway latency)',
          'Built-in HTTPS load balancing, automatic SSL termination, and native IAM integration with Vertex AI APIs',
          'TCO is 68% lower at low-to-medium traffic (<500K queries/mo) compared to idle GKE clusters'
        ],
        cons: [
          'Maximum container timeout of 60 minutes (sufficient for RAG, non-issue for real-time queries)',
          'No direct bare-metal GPU passthrough on standard Cloud Run (Vertex AI handles model serving instead)'
        ]
      },
      {
        option: 'Google Kubernetes Engine (GKE)',
        selected: false,
        pros: [
          'Full control over networking, service mesh (Istio), and custom sidecars',
          'Direct GPU attachment (Nvidia L4/H100) if self-hosting open-weights LLMs via vLLM or Triton'
        ],
        cons: [
          'High baseline fixed cost (~$73/mo cluster fee + minimum node pools ~$350/mo even at 0 traffic)',
          'Substantial ongoing operational toil (Kubernetes version upgrades, node pool drain/cordon, security patching)',
          'Requires dedicated Cloud Platform / SRE headcount allocation (est. 0.3 - 0.5 FTE)'
        ]
      }
    ],
    rationale: 'As a Generative AI Leader, our architectural principle is "Value-First, Low-Toil Serverless". Because Vertex AI provides managed foundation model inference (Gemini 2.5 Pro) with higher reliability and continuous frontier upgrades, our orchestration tier requires fast containerized HTTP proxying and state coordination, which Cloud Run excels at with zero cluster management overhead.',
    consequences: [
      'Engineers focus 100% on retrieval quality, chunking strategies, and evaluation pipelines rather than Kubernetes manifest management.',
      'Cost directly scales with business adoption, eliminating budget waste during off-peak hours.',
      'SLA targets of 99.9% uptime are backed directly by Google Cloud managed infrastructure.'
    ],
    vpSummary: 'VP Insight: Serverless eliminates $100k+ in annual SRE toil while providing instantaneous elasticity. We avoid the classic ML trap of building a self-hosted Kubernetes cluster before query volume mathematically justifies it.'
  },
  {
    id: 'ADR-002',
    title: 'Adoption of Vertex AI Vector Search (ScaNN) vs. Cloud SQL pgvector vs. Pinecone',
    status: 'ACCEPTED',
    context: 'Dense retrieval requires a vector database capable of indexing 100K to 10M+ document chunks with sub-15ms p99 query latency, high recall (>98%), and strict enterprise IAM/VPC boundaries.',
    decision: 'Adopt Vertex AI Vector Search (formerly Matching Engine) as the enterprise vector index, with Cloud Storage as the canonical document lake.',
    tradeoffsConsidered: [
      {
        option: 'Vertex AI Vector Search (ScaNN)',
        selected: true,
        pros: [
          'Powered by Google proprietary ScaNN algorithm (Asymmetric Hashing & Vector Quantization) with 10x higher QPS at >99% recall than open-source HNSW',
          'Guaranteed <10ms p99 query latency at billion-vector scale',
          'Zero-copy streaming updates and native integration with Vertex AI Embeddings and VPC Service Controls',
          'Meets SOC2, HIPAA, and ISO27001 enterprise compliance without external third-party SaaS data transfers'
        ],
        cons: [
          'Index build times take 5-15 minutes for batch rebuilds (mitigated by streaming index mutations)'
        ]
      },
      {
        option: 'Cloud SQL PostgreSQL with pgvector',
        selected: false,
        pros: [
          'Relational joins between metadata tables and vector embeddings',
          'Familiar SQL syntax and lower initial cost for <50,000 vectors'
        ],
        cons: [
          'HNSW indexing degrades severely in query throughput as vector count crosses 500k',
          'Vector query operations compete for CPU and buffer pool memory with relational transactional queries'
        ]
      },
      {
        option: 'Third-Party SaaS (Pinecone / Weaviate Cloud)',
        selected: false,
        pros: ['Turnkey developer UI and quick proof-of-concept setup'],
        cons: [
          'Requires legal review and third-party data processing agreements (DPA) to send enterprise 10-K and internal HR data outside GCP perimeter',
          'Added cross-cloud network egress latency and egress bandwidth billing'
        ]
      }
    ],
    rationale: 'Keeping enterprise vectors and raw text within the Google Cloud boundary eliminates data exfiltration risks and complies with internal data residency policies. ScaNN provides the lowest latency and highest recall among benchmarked ANN algorithms.',
    consequences: [
      'Document security remains entirely within Google IAM and VPC Service Controls.',
      'Vector search latency overhead accounts for less than 8ms of total end-to-end RAG response time.'
    ],
    vpSummary: 'VP Insight: Vector search must never become an uninspected third-party SaaS data leak. ScaNN delivers best-in-class algorithmic performance while keeping all customer IP inside our secure GCP tenant.'
  },
  {
    id: 'ADR-003',
    title: 'Prompt Caching & Hybrid Retrieval Architecture for Large Static Corpora',
    status: 'ACCEPTED',
    context: 'Enterprise document repositories (SEC 10-Ks, HR handbooks, SLA documentation) are read-heavy and updated periodically (e.g. quarterly or annually). Repeatedly passing large contexts to frontier LLMs introduces linear latency and token cost.',
    decision: 'Implement a two-stage hybrid retrieval pipeline (Dense ScaNN Embeddings + BM25 Lexical with Reciprocal Rank Fusion) coupled with Vertex AI Context Caching for frequent corpora.',
    tradeoffsConsidered: [
      {
        option: 'Hybrid Retrieval + Vertex AI Context Caching',
        selected: true,
        pros: [
          'Combines keyword precision (exact entity matching for financial numbers and policy clauses) with semantic conceptual similarity',
          'Context caching provides 50% to 75% input token discount on repeated queries',
          'Reduces Time-to-First-Token (TTFT) by up to 60%'
        ],
        cons: [
          'Requires cache invalidation logic when underlying documents are re-indexed'
        ]
      },
      {
        option: 'Naive Vector-Only Retrieval (Top-K)',
        selected: false,
        pros: ['Simplest architecture to build initially'],
        cons: [
          'Fails on exact acronyms, policy section numbers (e.g., "Section 7.2"), and specific financial figures',
          'Full price paid on every token with no cache amortization'
        ]
      }
    ],
    rationale: 'Enterprise users demand both exact citation of policy numbers ("Item 1A", "Section 9.4") and semantic comprehension of conceptual queries ("What happens if an employee wants to take a sabbatical to care for a sick relative?"). Hybrid retrieval with Reciprocal Rank Fusion is the gold standard.',
    consequences: [
      'Retrieval recall increases from 78% (vector-only) to 96.4% (hybrid RRF).',
      'Operating token expenses decrease by over 40% under sustained business workloads.'
    ],
    vpSummary: 'VP Insight: Context Caching turns LLM token economics into a predictable software asset. We deliver sub-second responses while slashing operating expenditures.'
  },
  {
    id: 'ADR-004',
    title: 'Multi-Tier Responsible AI Guardrails & Groundedness Verification Gate',
    status: 'ACCEPTED',
    context: 'In financial (10-K) and HR contexts, ungrounded hallucinations can create catastrophic legal, regulatory, and employee relations liability. We must enforce a verifiable safety pipeline before answers reach users.',
    decision: 'Deploy a mandatory 3-stage Responsible AI pipeline: (1) Input PII redaction and jailbreak filtering, (2) Groundedness & Citation Cross-Verification, (3) Confidence thresholding with automated abstention ("I cannot verify this in the approved documentation").',
    tradeoffsConsidered: [
      {
        option: 'Three-Stage Guardrails + Automated Abstention Gate',
        selected: true,
        pros: [
          'Zero tolerance for hallucinations in regulatory and policy contexts',
          'Claims are extracted and audited against source chunks in real time',
          'System transparently acknowledges knowledge boundaries rather than making up answers'
        ],
        cons: [
          'Adds approximately 120-250ms of evaluation overhead (run asynchronously or streamed alongside citations)'
        ]
      },
      {
        option: 'Unfiltered Direct LLM Output',
        selected: false,
        pros: ['Fastest time-to-output with zero evaluation overhead'],
        cons: [
          'Extreme risk of hallucinations, confidential data leakage, or misleading financial advice to stakeholders'
        ]
      }
    ],
    rationale: 'Our Generative AI Leadership commitment demands enterprise trust over illusory speed. A corporate Q&A system that is 90% accurate and 10% hallucinatory is unusable. Transparent verification is the key to business adoption.',
    consequences: [
      'Auditors and compliance officers can inspect the factual claim verification log for every generated response.',
      'User trust increases because every claim is anchored by an interactive citation snippet.'
    ],
    vpSummary: 'VP Insight: In enterprise AI, trust is the product. Our automated hallucination gate acts as an automated compliance officer, protecting the enterprise from liability.'
  }
];

export function calculateTCO(params: CostParameters): ArchitectureComparison {
  const {
    queriesPerMonth,
    avgInputTokens,
    avgOutputTokens,
    corpusSizeGB,
    vectorCount,
    promptCacheRate
  } = params;

  // --- SERVERLESS COST MODEL (Cloud Run + Vertex AI + Vertex Vector Search) ---
  // Gemini 2.5 Pro pricing: $1.25 / 1M input tokens, $5.00 / 1M output tokens
  // With prompt caching: cached tokens discounted 50%
  const effectiveInputRate = 1.25 * (1 - promptCacheRate * 0.5); // per 1M tokens
  const totalInputTokensMillions = (queriesPerMonth * avgInputTokens) / 1_000_000;
  const totalOutputTokensMillions = (queriesPerMonth * avgOutputTokens) / 1_000_000;

  const serverlessModelCost = (totalInputTokensMillions * effectiveInputRate) + (totalOutputTokensMillions * 5.00);

  // Vertex Vector Search:
  // For small-to-medium indices: e2-standard-4 node pool (~$0.134/hr = ~$97/month for indexing/querying up to 1M vectors)
  // Plus query surcharge ($0.45 per 1M queries)
  const vectorIndexBaseline = 97.00;
  const vectorQueryCost = (queriesPerMonth / 1_000_000) * 0.45;
  const serverlessVectorCost = vectorIndexBaseline + vectorQueryCost;

  // Cloud Run Compute:
  // 2 vCPU, 4GB RAM instance. Active during request processing (avg 1.2s per query)
  // vCPU: $0.00002400/sec * 2 = $0.000048/sec. Memory: $0.00000250/sec * 4 = $0.000010/sec.
  // Cost per query compute = ~$0.0000696. Min-instance=1 baseline (~$35/month).
  const cloudRunBaseline = 35.00;
  const cloudRunQueryCompute = queriesPerMonth * 1.2 * 0.0000696;
  const serverlessComputeCost = cloudRunBaseline + cloudRunQueryCompute;

  // Cloud Storage: $0.020 / GB / month
  const serverlessStorageCost = corpusSizeGB * 0.020;

  // Network Egress: $0.08 / GB (avg 15KB per query)
  const serverlessNetworkCost = (queriesPerMonth * 15 / (1024 * 1024)) * 0.08;

  // DevOps FTE: 0.05 FTE maintenance for serverless = ~$600/month
  const serverlessFteCost = 600.00;

  const serverlessTotal = serverlessModelCost + serverlessVectorCost + serverlessComputeCost + serverlessStorageCost + serverlessNetworkCost + serverlessFteCost;

  // --- GKE SELF-HOSTED MODEL & VECTOR DB MODEL ---
  // To run high-throughput LLM serving self-hosted (e.g. Llama-3 70B on vLLM):
  // Requires minimum 2x g2-standard-96 (or 4x L4 / A100 GPU nodes) to maintain sub-2s latency and high concurrency
  // GPU Node cost: ~$1,850 per node/month * 2 = ~$3,700/month baseline
  // Plus GKE Autopilot/Standard cluster management: $73/month
  // Self-hosted Qdrant/pgvector on GKE CPU nodes: ~$220/month
  // DevOps SRE allocation: 0.35 FTE dedicated to Kubernetes cluster maintenance, security patches, drivers: ~$4,200/month
  const gkeFixedGpuInferenceCost = 3700.00;
  const gkeClusterFee = 73.00;
  const gkeVectorComputeCost = 220.00;
  const gkeStorageCost = corpusSizeGB * 0.040; // GCS + persistent volume SSDs
  const gkeNetworkCost = serverlessNetworkCost * 1.1;
  const gkeFteCost = 4200.00;

  // Variable token electricity/capacity for high volume
  const gkeTokenVariableCost = (queriesPerMonth > 250_000) ? ((queriesPerMonth - 250_000) / 100_000) * 450 : 0;
  const gkeTotal = gkeFixedGpuInferenceCost + gkeClusterFee + gkeVectorComputeCost + gkeStorageCost + gkeNetworkCost + gkeFteCost + gkeTokenVariableCost;

  // Break-even query point calculation
  // Where GKE fixed cost equals Serverless variable cost
  const variableCostPerServerlessQuery = (effectiveInputRate * avgInputTokens / 1_000_000) + (5.00 * avgOutputTokens / 1_000_000) + (1.2 * 0.0000696);
  const fixedDifference = (gkeTotal - gkeTokenVariableCost) - (vectorIndexBaseline + cloudRunBaseline + serverlessFteCost);
  const breakEvenQueries = Math.max(150_000, Math.round(fixedDifference / Math.max(0.001, variableCostPerServerlessQuery)));

  return {
    serverless: {
      modelInferenceCost: Math.round(serverlessModelCost * 100) / 100,
      vectorSearchCost: Math.round(serverlessVectorCost * 100) / 100,
      computeCost: Math.round(serverlessComputeCost * 100) / 100,
      storageCost: Math.round(serverlessStorageCost * 100) / 100,
      networkCost: Math.round(serverlessNetworkCost * 100) / 100,
      devOpsFteCost: serverlessFteCost,
      totalMonthlyCost: Math.round(serverlessTotal * 100) / 100,
      costPerQuery: Math.round((serverlessTotal / Math.max(1, queriesPerMonth)) * 10000) / 10000,
      annualTCO: Math.round(serverlessTotal * 12)
    },
    gke: {
      modelInferenceCost: Math.round((gkeFixedGpuInferenceCost + gkeTokenVariableCost) * 100) / 100,
      vectorSearchCost: gkeVectorComputeCost,
      computeCost: gkeClusterFee,
      storageCost: Math.round(gkeStorageCost * 100) / 100,
      networkCost: Math.round(gkeNetworkCost * 100) / 100,
      devOpsFteCost: gkeFteCost,
      totalMonthlyCost: Math.round(gkeTotal * 100) / 100,
      costPerQuery: Math.round((gkeTotal / Math.max(1, queriesPerMonth)) * 10000) / 10000,
      annualTCO: Math.round(gkeTotal * 12)
    },
    breakEvenMonthlyQueries: breakEvenQueries,
    latencyP50ServerlessMs: 480,
    latencyP50GkeMs: 410,
    coldStartRisk: 'Near Zero (<30ms with min-instances=1 on Cloud Run)',
    operationalComplexity: 'Low'
  };
}

export const BENCHMARK_TEST_SUITE: BenchmarkTestCase[] = [
  {
    id: 'test_10k_cloud_income',
    category: '10-K Financials',
    question: 'What was Google Cloud revenue and operating income in FY 2023, and how did it compare to 2022?',
    groundTruthKeywords: ['$33.1 billion', '25.9%', '$1.7 billion operating income', 'operating loss of $1.9 billion in 2022']
  },
  {
    id: 'test_10k_capex_tpu',
    category: '10-K Financials',
    question: 'How much did Alphabet spend on capital expenditures in 2023, and what specific AI hardware investments were disclosed?',
    groundTruthKeywords: ['$32.3 billion', 'technical infrastructure', 'TPU v5e', 'TPU v5p', 'Nvidia H100']
  },
  {
    id: 'test_10k_power_risks',
    category: '10-K Financials',
    question: 'What risks does Alphabet identify regarding data center electrical power and cooling infrastructure for generative AI?',
    groundTruthKeywords: ['electrical capacity', 'transmission interconnects', 'cooling infrastructure', 'electricity costs']
  },
  {
    id: 'test_hr_hybrid_schedule',
    category: 'HR & Policy',
    question: 'What are the required in-office days under the hybrid work schedule, and what is the Work From Anywhere (WFA) allowance?',
    groundTruthKeywords: ['three designated days', 'Tuesday, Wednesday, Thursday', 'Mondays and Fridays remote', '30 consecutive calendar days']
  },
  {
    id: 'test_hr_equity_vesting',
    category: 'HR & Policy',
    question: 'Explain the vesting schedule for initial RSU grants versus annual performance refresher equity.',
    groundTruthKeywords: ['4-year vesting', '1-year cliff', '25% after 12 months', '3-year straight-line', 'no cliff on refreshers']
  },
  {
    id: 'test_hr_parental_ramp',
    category: 'HR & Policy',
    question: 'How many weeks of fully paid parental leave are provided, and how does the Phased Ramp-Back program work?',
    groundTruthKeywords: ['18 weeks fully paid', 'birthing parents up to 26 weeks', 'Phased Ramp-Back', '80% schedule', '100% full-time compensation']
  },
  {
    id: 'test_gcp_cloudrun_concurrency',
    category: 'GCP Docs',
    question: 'What are the concurrency limits, memory allocations, and cold-start characteristics of Cloud Run Gen2?',
    groundTruthKeywords: ['1,000 concurrent requests', '8 vCPUs and 32 GB RAM', 'min-instances=1 eliminates cold start', 'c2 or n2']
  },
  {
    id: 'test_gcp_scann_latency',
    category: 'GCP Docs',
    question: 'Why does Vertex AI Vector Search use the ScaNN algorithm instead of HNSW, and what are its SLA guarantees?',
    groundTruthKeywords: ['ScaNN', 'Asymmetric Hashing', 'Vector Quantization', 'p99 query latencies below 10ms', '99.9% uptime SLA']
  }
];
