import { DocumentItem, DocumentChunk } from '../types';

export function chunkText(text: string, documentId: string, documentTitle: string, category: string, chunkSize = 420, overlap = 60): DocumentChunk[] {
  // Paragraph and sentence-aware chunking
  const paragraphs = text.split(/\n\n+/);
  const chunks: DocumentChunk[] = [];
  let currentChunkText = '';
  let chunkIndex = 1;

  for (const para of paragraphs) {
    const trimmed = para.trim();
    if (!trimmed) continue;

    if ((currentChunkText + '\n\n' + trimmed).length <= chunkSize * 4) {
      currentChunkText = currentChunkText ? currentChunkText + '\n\n' + trimmed : trimmed;
    } else {
      if (currentChunkText) {
        chunks.push({
          id: `${documentId}_chk_${chunkIndex}`,
          documentId,
          documentTitle,
          category,
          chunkIndex,
          text: currentChunkText,
          tokenCount: Math.round(currentChunkText.length / 3.8),
        });
        chunkIndex++;
        // Maintain overlap
        const words = currentChunkText.split(' ');
        const overlapWords = words.slice(-Math.min(words.length, overlap));
        currentChunkText = overlapWords.join(' ') + '\n\n' + trimmed;
      } else {
        currentChunkText = trimmed;
      }
    }
  }

  if (currentChunkText) {
    chunks.push({
      id: `${documentId}_chk_${chunkIndex}`,
      documentId,
      documentTitle,
      category,
      chunkIndex,
      text: currentChunkText,
      tokenCount: Math.round(currentChunkText.length / 3.8),
    });
  }

  return chunks;
}

export const INITIAL_DOCUMENTS: DocumentItem[] = [
  {
    id: 'doc_alphabet_10k',
    title: 'Alphabet Inc. Form 10-K (Annual Filing FY23-FY24)',
    category: '10-K Financials',
    source: 'SEC EDGAR Public Disclosures - CIK 0001652044',
    date: 'February 2024',
    totalTokens: 1420,
    chunkCount: 5,
    content: `ITEM 1. BUSINESS & REVENUE OVERVIEW:
Alphabet is a global technology leader. For the fiscal year ended December 31, 2023, consolidated revenues were $307.4 billion, reflecting an increase of 9% year-over-year. Google Services revenues were $272.6 billion, driven by Google Search & other advertising ($175.0 billion) and YouTube advertising ($31.5 billion). Google Cloud revenues reached $33.1 billion, up 25.9% year-over-year, generating operating income of $1.7 billion compared to an operating loss of $1.9 billion in 2022, representing significant operational leverage.

ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS - AI & CAPITAL EXPENDITURE:
Capital expenditures were $32.3 billion, predominantly driven by investments in technical infrastructure, including servers and network equipment to power artificial intelligence (AI) workloads. We significantly scaled deployments of our custom Tensor Processing Units (TPUs), specifically TPU v5e and TPU v5p, alongside third-party GPU clusters (Nvidia H100/A100). Management expects CapEx investments to continue increasing substantially in FY2024 to support training and real-time inference demands for Gemini 1.5, Gemini 2.0, and Gemini 2.5 foundation models across our consumer and enterprise Google Cloud product suites.

ITEM 1A. RISK FACTORS - GENERATIVE AI COMPETITION & INFRASTRUCTURE BOTTLENECKS:
We face intense competition in AI research, model pre-training, and enterprise cloud solutions. Rapid developments in large language models (LLMs) by competitors may adversely impact user engagement on Google Search if competitors provide alternative question-answering interfaces. Furthermore, deploying large-scale real-time generative models requires substantial compute and electrical power. We face potential risks in procuring sufficient data center electrical capacity, transmission interconnects, and cooling infrastructure. If electricity costs escalate or if power availability delays data center buildouts, our margin profiles and capacity to serve generative queries at sub-second latencies could be materially impaired.

ITEM 1A. REGULATORY, ANTITRUST & COPYRIGHT RISKS:
Our AI and search products are subject to heightened antitrust review and regulatory enforcement globally, including investigations under the European Union Digital Markets Act (DMA) and ongoing antitrust litigation with the U.S. Department of Justice regarding search distribution and ad tech. Additionally, training frontier generative models on public datasets has subjected the company to evolving copyright, intellectual property, and fair-use litigation. Adverse rulings or legislative mandates requiring licensing fees for public training corpora could materially increase operational expenditures.`,
    chunks: [],
  },
  {
    id: 'doc_enterprise_hr_policy',
    title: 'Global Enterprise Workplace & Generative AI Policy',
    category: 'HR & Policy',
    source: 'Enterprise People Operations & Legal Compliance Handbook v4.2',
    date: 'January 2024',
    totalTokens: 1180,
    chunkCount: 4,
    content: `SECTION 3.1: WORKPLACE FLEXIBILITY & HYBRID WORK SCHEDULE
Our enterprise operates on a collaborative hybrid model. All regular full-time employees are expected to work from an assigned corporate office a minimum of three (3) designated days per week (Tuesday, Wednesday, and Thursday). Mondays and Fridays are designated flexible remote days. Employees may request formal fully remote status subject to VP-level People Ops approval based on role portability and sustained high performance. In addition, employees in good standing are entitled to the "Work From Anywhere" (WFA) benefit: up to thirty (30) consecutive calendar days per fiscal year of international or domestic remote work, provided compliance with local tax and data residency jurisdictions is cleared with Global Mobility.

SECTION 4.5: TOTAL REWARDS, EQUITY & ANNUAL PERFORMANCE REFRESHERS
Equity is an essential pillar of long-term alignment. Initial Restricted Stock Unit (RSU) grants follow a standard 4-year vesting schedule with a 1-year cliff (25% vesting after 12 months) and quarterly vesting thereafter. Annual equity refresher grants are determined during the Q1 compensation cycle based on calibrated performance ratings (Exceeds High, Meets All, Needs Improvement). Refresher grants vest over three (3) years on a straight-line quarterly cadence with no cliff. The company maintains an Employee Stock Purchase Plan (ESPP) allowing eligible employees to contribute up to 15% of base salary to purchase company shares at a 15% discount to the lower of the offering date or purchase date fair market value.

SECTION 7.2: PARENTAL, CAREGIVER & MEDICAL LEAVE PROVISIONS
The company provides eighteen (18) weeks of fully paid parental leave for all eligible parents (birth, adoption, surrogacy, or foster placement) regardless of gender. Birthing parents are eligible for an additional 6 to 8 weeks of paid short-term pregnancy disability leave, providing up to 26 weeks of total paid time off. All paid parental leaves include a "Phased Ramp-Back" period: upon returning, employees may work an 80% schedule for four (4) weeks while receiving 100% of full-time base compensation. In addition, employees are granted four (4) weeks of paid family caregiver leave annually for immediate family members experiencing critical health conditions.

SECTION 9.4: ACCEPTABLE USE OF GENERATIVE AI & INTELLECTUAL PROPERTY PROTECTION
Employees are encouraged to use company-approved, enterprise-grade AI tools (e.g., Google Workspace Gemini Enterprise, private Vertex AI endpoints) for drafting, code assistance, and summarization. Employees are strictly prohibited from uploading confidential source code, internal roadmap documents, non-public financial disclosures, or customer personally identifiable information (PII) to public, non-enterprise AI chatbots (such as consumer web interfaces whose terms of service permit data retention for model retraining). Any code generated by an AI assistant must be thoroughly reviewed for security vulnerabilities and licensing compliance (specifically excluding copyleft GPL v3 contaminations in commercial libraries).`,
    chunks: [],
  },
  {
    id: 'doc_gcp_cloudrun_vertex_sla',
    title: 'GCP Cloud Run & Vertex AI Vector Search Architecture Spec',
    category: 'GCP Docs',
    source: 'Google Cloud Architecture Center & Enterprise SLA Whitepaper',
    date: 'March 2024',
    totalTokens: 1350,
    chunkCount: 4,
    content: `SPEC 1: CLOUD RUN GEN2 RUNTIME FOR AI MICROSERVICES
Cloud Run Gen2 is a fully managed serverless container execution platform ideal for high-throughput AI API gateways and RAG orchestration microservices. Gen2 runs on a dedicated c2 or n2 virtual machine architecture with host virtualization, providing full Linux compatibility, faster CPU clock speeds, and fast cold-starts (<450ms container startup). Each Cloud Run instance can scale from 0 to 1,000 concurrent requests per container, with maximum instance allocations of 8 vCPUs and 32 GB RAM. For latency-critical enterprise RAG services where tail latency (p99) must stay under 500ms, setting 'min-instances=1' eliminates cold-start penalties entirely while maintaining automatic scale-to-zero capabilities for secondary workers.

SPEC 2: VERTEX AI VECTOR SEARCH (SCANN ALGORITHM & LATENCY SLA)
Vertex AI Vector Search (formerly Matching Engine) is Google Cloud's distributed vector database, powering sub-millisecond vector similarity search at billion-scale embeddings. It utilizes Google's proprietary ScaNN (Scalable Nearest Neighbors) algorithm, which implements vector quantization, anisotropic loss quantization, and Tree-AH (Asymmetric Hashing). ScaNN achieves 99.0%+ recall at 10x higher queries-per-second (QPS) than standard HNSW (Hierarchical Navigable Small World) algorithms found in pgvector or Pinecone. Vertex Vector Search offers an enterprise SLA of 99.9% uptime, delivers p99 query latencies below 10ms for 768-dimension embeddings, and supports streaming real-time index updates without full re-indexing downtime.

SPEC 3: VERTEX AI GEMINI PROMPT CACHING & CONTEXT ECONOMICS
Vertex AI supports Context Caching for Gemini 1.5 Pro, 2.0 Flash, and 2.5 Pro. For enterprise applications with large static document corpuses (e.g., quarterly 10-K filings, compliance repositories, or policy handbooks totaling over 32,768 tokens), developers can cache the document prefix in Vertex AI memory. Subsequent user queries referencing the cached context receive a 50% to 75% reduction in input token costs and up to 70% reduction in Time-to-First-Token (TTFT) latency. Cached contexts incur an hourly storage rate of $1.00 per 1 million tokens/hour with a configurable TTL (time-to-live), resulting in significant net TCO savings when query volume exceeds 50 queries per hour over the same static corpus.

SPEC 4: ENTERPRISE SECURITY, VPC SERVICE CONTROLS & RESPONSIBLE AI GUARDRAILS
To satisfy Fortune 500 enterprise security requirements, the RAG architecture incorporates Google Cloud VPC Service Controls (VPC-SC) to establish an isolated security perimeter around Cloud Storage buckets, Vertex AI endpoints, and Cloud Run services, preventing data exfiltration. All data at rest is encrypted using Customer-Managed Encryption Keys (CMEK) via Cloud KMS. The generative serving pipeline enforces Vertex AI Responsible AI safety filters (hate speech, sexual content, harassment, dangerous content) alongside automated output Groundedness Evaluation checks that compute citation attribution overlap before emitting tokens to the client application.`,
    chunks: [],
  }
];

// Initialize chunking for default docs
for (const doc of INITIAL_DOCUMENTS) {
  doc.chunks = chunkText(doc.content, doc.id, doc.title, doc.category);
  doc.chunkCount = doc.chunks.length;
}
